import React from "react";

const Footer = () => {
    return (
        <div style={{color:"#fff", width:"100%", height:"30px", backgroundColor:"#212529", marginTop:"auto"}}>
    
        </div>
    )
}

export default Footer;