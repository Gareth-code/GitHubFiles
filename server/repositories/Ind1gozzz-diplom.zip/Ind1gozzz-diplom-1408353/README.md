# diplom
 oh, yeah
