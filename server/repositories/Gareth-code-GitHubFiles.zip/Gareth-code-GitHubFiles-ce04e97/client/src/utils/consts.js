export const SEARCH_ROUTE = "/search"
export const PROJECTS_ROUTE = "/projects"
export const PRINFO_ROUTE = "/projectinfo"