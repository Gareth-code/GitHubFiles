const config = {
  PORT: 5000,
  DB_HOST: "127.0.0.1",
  DB_PORT: 5432,
  DB_USER: "postgres",
  MAIN_DB_NAME: "course",
  MAIN_DB_PASSWORD: "123",
  LEARNING_DB_NAME: "learndb",
  LEARNING_DB_PASSWORD: "123",
  SECRET_KEY: "AWse;jgg34934gl12knAWFPoi40twlkn2@"
}

module.exports = config