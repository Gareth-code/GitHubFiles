app.component('registration', {
    template:
    /* HTML */
    `
    
    `,

})